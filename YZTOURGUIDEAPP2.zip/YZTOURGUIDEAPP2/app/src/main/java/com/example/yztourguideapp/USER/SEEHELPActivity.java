package com.example.yztourguideapp.USER;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.yztourguideapp.MODEL.helpmodel;
import com.example.yztourguideapp.R;
import com.example.yztourguideapp.VIEWHOLDER.myviewholderfor_help;
import com.example.yztourguideapp.common.LOGINActivity;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SEEHELPActivity extends AppCompatActivity {
    EditText inputsearch;
    private RecyclerView recyclerView;
    private RelativeLayout relativeLayout;
    FloatingActionButton floatingActionButton;
    FirebaseRecyclerOptions<helpmodel> options;
    FirebaseRecyclerAdapter<helpmodel, myviewholderfor_help> adapter;
    DatabaseReference Dataref;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seehelp);
        recyclerView=findViewById(R.id.recylerview);
        Dataref= FirebaseDatabase.getInstance().getReference().child("help");
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setHasFixedSize(true);
        firebaseAuth=FirebaseAuth.getInstance();
        LOADData();
    }
    private void LOADData() {
        options=new FirebaseRecyclerOptions.Builder<helpmodel>().setQuery(Dataref, helpmodel.class).build();
        adapter=new FirebaseRecyclerAdapter<helpmodel, myviewholderfor_help>(options) {
            @Override
            protected void onBindViewHolder(@NonNull myviewholderfor_help holder, int position, @NonNull helpmodel model) {
                holder.textViewhelptitle.setText(model.getTitle());
                holder.textViewhelpdescr.setText(model.getDescription());
            }

            @NonNull
            @Override
            public myviewholderfor_help onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_layoutforhelp,parent,false );

                return new myviewholderfor_help(v);
            }
        };
        adapter.startListening();
        recyclerView.setAdapter(adapter );


    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu_1,menu);
        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        Intent intent;
        switch (id){
            case R.id.item1:
                Toast.makeText(this, "user logged out", Toast.LENGTH_SHORT).show();
                firebaseAuth.signOut();
                intent=new Intent(getApplicationContext(), LOGINActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.item2:
                intent=new Intent(getApplicationContext(), SEEUPLOADEDANNOUNCEActivity.class);
                startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}