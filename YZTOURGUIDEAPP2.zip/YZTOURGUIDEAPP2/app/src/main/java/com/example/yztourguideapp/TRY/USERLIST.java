//package com.example.yztourguideapp.TRY;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import android.content.Intent;
//import android.os.Bundle;
//
//import com.example.yztourguideapp.ADMIN.MANAGEANNOUNCEMENT;
//import com.example.yztourguideapp.ADMIN.MANAGEBOOK;
//import com.example.yztourguideapp.ADMIN.UPLOADANNOUNCEActivity;
//import com.example.yztourguideapp.MODEL.Bookmodel;
//import com.example.yztourguideapp.R;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//
//import java.util.ArrayList;
//
//public class USERLIST extends AppCompatActivity implements adapter.BookClickInterface {
//    RecyclerView recyclerView;
//    DatabaseReference database;
//    adapter myadapter;
//    ArrayList<Bookmodel> list;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_userlist);
//        recyclerView=findViewById(R.id.userlist);
//        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//        recyclerView.setHasFixedSize(true);
//        database= FirebaseDatabase.getInstance().getReference().child("book");
//        list=new ArrayList<>();
//        myadapter=new adapter(getApplicationContext(),list);
//        recyclerView.setAdapter(myadapter);
//        database.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for (DataSnapshot dataSnapshot:snapshot.getChildren()){
//                    Bookmodel model=dataSnapshot.getValue(Bookmodel.class);
//                    list.add(model);
//                }
//                myadapter.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//            }
//        });
//
//    }
//
//    @Override
//    public void onBookClick(int position) {
//        // calling a method to display a bottom sheet on below line.
//        //Intent intent=new Intent(getApplicationContext(),MANAGEBOOK.class);
//      //  intent.putExtra("bookkey",boo)
//        displayBottomSheet(list.get(position));
////        // calling a method to display a bottom sheet on below line.
////
//
//    }
//
//      private void displayBottomSheet(Bookmodel bookmodel) {
//        Intent intent=new Intent(getApplicationContext(), UPLOADANNOUNCEActivity.class);
//       // intent.putExtra("bookkey",bookmodel);
//        //String x=getRef(holder.getBindingAdapterPosition()).getKey();
//        startActivity(intent);
//    }
//}