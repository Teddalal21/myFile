package com.example.yztourguideapp.ADMIN;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.example.yztourguideapp.MODEL.Bookmodel;
import com.example.yztourguideapp.MODEL.helpmodel;
import com.example.yztourguideapp.R;
import com.example.yztourguideapp.USER.UPLOADBOOKActivity;
import com.example.yztourguideapp.VIEWHOLDER.myviewholderfor_help;
import com.example.yztourguideapp.VIEWHOLDER.myviewholderforbook;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class SEEBOOK extends AppCompatActivity {
    FloatingActionButton floatingActionButtonforbook;
    EditText searchforbook;
    RecyclerView recyclerViewforbook;
    DatabaseReference databaseReference;
    FirebaseRecyclerOptions<Bookmodel> options;
    FirebaseRecyclerAdapter<Bookmodel, myviewholderforbook> adapterbook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seebook);
        floatingActionButtonforbook=findViewById(R.id.floatingbtnforbook);
        searchforbook=findViewById(R.id.inputsearchforbook);
        recyclerViewforbook=findViewById(R.id.recylerviewforbook);
        floatingActionButtonforbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), UPLOADBOOKActivity.class));
            }
        });
        databaseReference= FirebaseDatabase.getInstance().getReference().child("book");
        LOADBOOK();



    }

    private void LOADBOOK() {
        options=new FirebaseRecyclerOptions.Builder<Bookmodel>().setQuery(databaseReference,Bookmodel.class).build();
        adapterbook=new FirebaseRecyclerAdapter<Bookmodel, myviewholderforbook>(options) {
            @Override
            protected void onBindViewHolder(@NonNull myviewholderforbook holder, int position, @NonNull Bookmodel model) {
                holder.textViewforbook.setText(model.getDestination());
                Picasso.get().load(model.getImageurl()).into(holder.imageViewforbook);

            }

            @NonNull
            @Override
            public myviewholderforbook onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_layoutforbook,parent,false);

                return new myviewholderforbook(view);
            }
        };
        adapterbook.startListening();
        recyclerViewforbook.setAdapter(adapterbook);


    }
}