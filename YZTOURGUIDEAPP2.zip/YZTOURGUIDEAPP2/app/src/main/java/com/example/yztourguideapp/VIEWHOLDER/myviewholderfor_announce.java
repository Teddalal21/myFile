package com.example.yztourguideapp.VIEWHOLDER;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.yztourguideapp.R;

public class myviewholderfor_announce extends RecyclerView.ViewHolder {

   public ImageView imageViewforannounce;
   public TextView textViewofannounce;
    public View v;
    public myviewholderfor_announce(@NonNull View itemView) {
        super(itemView);
        imageViewforannounce=itemView.findViewById(R.id.imageforannounce);
        textViewofannounce=itemView.findViewById(R.id.textViewforannounce);
        v=itemView;
    }
}