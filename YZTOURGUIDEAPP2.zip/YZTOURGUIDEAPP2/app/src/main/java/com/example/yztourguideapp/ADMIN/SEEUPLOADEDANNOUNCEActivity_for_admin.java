
package com.example.yztourguideapp.ADMIN;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.yztourguideapp.MODEL.tourmodel;
import com.example.yztourguideapp.R;
import com.example.yztourguideapp.common.LOGINActivity;
import com.example.yztourguideapp.VIEWHOLDER.myviewholderfor_announce;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

public class SEEUPLOADEDANNOUNCEActivity_for_admin extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private EditText inputsearch;
    private RecyclerView recyclerview;
    private RelativeLayout relativeLayout;
    FloatingActionButton floatingActionButton;
    FirebaseRecyclerOptions<tourmodel> options;
    FirebaseRecyclerAdapter<tourmodel, myviewholderfor_announce> adapter;
    DatabaseReference Dataref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seeuploadedannounceactivity_for_admin);
        Dataref= FirebaseDatabase.getInstance().getReference().child("upload_tour");
        inputsearch=findViewById(R.id.inputsearch);
        recyclerview=findViewById(R.id.recylerview);
        recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerview.setHasFixedSize(true);
        floatingActionButton=findViewById(R.id.floatingbtn);
        firebaseAuth=FirebaseAuth.getInstance();
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), UPLOADANNOUNCEActivity.class));
            }
        });

        LOADData("");
        inputsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(editable.toString()!=null){
                    LOADData(editable.toString());
                }
                else{
                    LOADData("");
                }
            }
        });


    }
    public  void LOADData(String data){
        //dataref refers
        Query query=Dataref.orderByChild("title").startAt(data).endAt(data+"\uf8ff");
        options=new FirebaseRecyclerOptions.Builder<tourmodel>().setQuery(query, tourmodel.class).build();
        adapter=new FirebaseRecyclerAdapter<tourmodel, myviewholderfor_announce>(options) {
            @Override
            protected void onBindViewHolder(@NonNull myviewholderfor_announce holder, int position, @NonNull tourmodel model) {
                holder.textViewofannounce.setText(model.getTitle());
                Picasso.get().load(model.getImageurl()).into(holder.imageViewforannounce);
                holder.v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(getApplicationContext(), MANAGEANNOUNCEMENT.class);
                        intent.putExtra("tourkey",getRef(holder.getBindingAdapterPosition()).getKey());
                        //String x=getRef(holder.getBindingAdapterPosition()).getKey();
                        startActivity(intent);
                        // bottomsheet(getRef(holder.getBindingAdapterPosition()).getKey());
                    }
                });
            }
            @NonNull
            @Override
            public myviewholderfor_announce onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_layoutforannounce,parent,false );

                return new myviewholderfor_announce(v);
            }
        };
        adapter.startListening();
        recyclerview.setAdapter(adapter );
    }
   /* private void bottomsheet(String key) {
        Dialog dialog=new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_adminmanage_uploaded);
        TextView textView1=dialog.findViewById(R.id.imagetitle);
        TextView Textview2=findViewById(R.id.textView_view_activity);
        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations= com.google.android.material.R.style.Animation_AppCompat_Dialog;
        dialog.getWindow().setGravity(Gravity.BOTTOM);
    }
*/
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu_2,menu);
        return  true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        Intent intent;
        switch (id){
            case R.id.item3:
                Toast.makeText(this, "user logged out", Toast.LENGTH_SHORT).show();
                firebaseAuth.signOut();
                intent=new Intent(getApplicationContext(), LOGINActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.item2:
                intent=new Intent(getApplicationContext(), SEEBOOK.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.item1:
                intent=new Intent(getApplicationContext(), SEEHELPActivity_for_admin.class);
                startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}