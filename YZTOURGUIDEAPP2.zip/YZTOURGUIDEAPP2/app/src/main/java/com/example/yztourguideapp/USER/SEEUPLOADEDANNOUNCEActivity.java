package com.example.yztourguideapp.USER;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.yztourguideapp.ADMIN.MANAGEANNOUNCEMENT;
import com.example.yztourguideapp.MODEL.tourmodel;
import com.example.yztourguideapp.R;
import com.example.yztourguideapp.VIEWHOLDER.myviewholderfor_help;
import com.example.yztourguideapp.common.LOGINActivity;
import com.example.yztourguideapp.VIEWHOLDER.myviewholderfor_announce;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

public class SEEUPLOADEDANNOUNCEActivity extends AppCompatActivity {
    EditText inputsearch;
    RecyclerView recyclerview;
    private RelativeLayout relativeLayout;
    FloatingActionButton floatingActionButton;
    FirebaseRecyclerOptions<tourmodel> options;
    FirebaseRecyclerAdapter<tourmodel, myviewholderfor_announce> adapter;
    DatabaseReference Dataref;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seeuploadedannounceactivity);
        Dataref= FirebaseDatabase.getInstance().getReference().child("upload_tour");
        inputsearch=findViewById(R.id.inputsearch);
        recyclerview=findViewById(R.id.recylerview);
        relativeLayout=findViewById(R.id.mainurr);
        firebaseAuth= FirebaseAuth.getInstance();
        recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerview.setHasFixedSize(true);
        LOADData("");
        inputsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void afterTextChanged(Editable editable) {
                if(editable.toString()!=null){
                    LOADData(editable.toString());
                }
                else{
                    LOADData("");
                }
            }
        });

    }

    private void LOADData(String data) {
        //dataref refers
        Query query=Dataref.orderByChild("title").startAt(data).endAt(data+"\uf8ff");
        options=new FirebaseRecyclerOptions.Builder<tourmodel>().setQuery(query,tourmodel.class).build();
        adapter=new FirebaseRecyclerAdapter<tourmodel, myviewholderfor_announce>(options ) {
            @Override
            protected void onBindViewHolder(@NonNull myviewholderfor_announce holder, int position, @NonNull tourmodel model) {
                holder. textViewofannounce.setText(model.getTitle());
                Picasso.get().load(model.getImageurl()).into(holder.imageViewforannounce);
                holder.v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent=new Intent(getApplicationContext(), SEEDEAILSOFANNOUNCE.class);
                        intent.putExtra("tourkey",getRef(holder.getBindingAdapterPosition()).getKey());
                        startActivity(intent);
                    }
                });
            }

            @NonNull
            @Override
            public myviewholderfor_announce onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_layoutforannounce,parent,false );

                return new myviewholderfor_announce(v);
            }
        };
        adapter.startListening();
        recyclerview.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu_1,menu);
        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        Intent intent;
        switch (id){
            case R.id.item1:
                Toast.makeText(this, "user logged out", Toast.LENGTH_SHORT).show();
                firebaseAuth.signOut();
                intent=new Intent(getApplicationContext(), LOGINActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.item2:
                intent=new Intent(getApplicationContext(), SEEHELPActivity.class);
                startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}