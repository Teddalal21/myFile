package com.example.yztourguideapp.VIEWHOLDER;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.yztourguideapp.R;

public class myviewholderfor_help extends RecyclerView.ViewHolder {

    public TextView textViewhelptitle;
    public TextView textViewhelpdescr;
    View v;
    public myviewholderfor_help(@NonNull View itemView) {
        super(itemView);
        textViewhelptitle=itemView.findViewById(R.id.textViewforhelpfortitle);
        textViewhelpdescr=itemView.findViewById(R.id.textViewforhelpdescr);
    }
}