package com.example.yztourguideapp.MODEL;

public class helpmodel {
    private String title;
    private String description;
    private String helpid;


    public helpmodel(String title, String description, String helpid) {
        this.title = title;
        this.description = description;
        this.helpid = helpid;
    }

    public helpmodel() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHelpid() {
        return helpid;
    }

    public void setHelpid(String helpid) {
        this.helpid = helpid;
    }
}