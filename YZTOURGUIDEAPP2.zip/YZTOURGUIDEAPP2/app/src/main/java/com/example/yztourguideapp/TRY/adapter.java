//package com.example.yztourguideapp.TRY;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.example.yztourguideapp.MODEL.Bookmodel;
//import com.example.yztourguideapp.R;
//import com.example.yztourguideapp.VIEWHOLDER.myviewholderforbook;
//import com.squareup.picasso.Picasso;
//
//import java.util.ArrayList;
//
//public class adapter extends RecyclerView.Adapter<adapter.myviewholder> {
//
//    Context context;
//    ArrayList<Bookmodel> list;
//    private BookClickInterface BookClickInterface;
//
//    public adapter(Context context, ArrayList<Bookmodel> list) {
//        this.context = context;
//        this.list = list;
//    }
//
//    @NonNull
//    @Override
//    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_layoutforbook,parent,false );
//
//        return new myviewholder(v);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull myviewholder holder, int position) {
//        Bookmodel model=list.get(position);
//        holder.textViewforbook.setText(model.getDestination());
//        Picasso.get().load(model.getImageurl()).into(holder.imageViewforbook);
//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                BookClickInterface.onBookClick(holder.getBindingAdapterPosition());
//            }
//        });
//
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return list.size();
//    }
//    // creating a interface for on click
//    public interface BookClickInterface {
//        void onBookClick(int position);
//    }
//    public  static class myviewholder extends RecyclerView.ViewHolder{
//        public ImageView imageViewforbook;
//        public TextView textViewforbook;
//        public myviewholder(@NonNull View itemView) {
//            super(itemView);
//            imageViewforbook=itemView.findViewById(R.id.bookimage);
//            textViewforbook=itemView.findViewById(R.id.destinations);
//        }
//
//
//    }
//}
