package com.example.yztourguideapp.ADMIN;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.yztourguideapp.MODEL.Bookmodel;
import com.example.yztourguideapp.R;
import com.example.yztourguideapp.USER.SEEUPLOADEDANNOUNCEActivity;
import com.example.yztourguideapp.common.REGISTRATIONActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class MANAGEBOOK extends AppCompatActivity {
    FirebaseDatabase firebaseDatabase;
    StorageReference Storageref;
    DatabaseReference databaseReference;
    private EditText editTextfullname,editTextphone,editTextdate,editTextdestination;
    private Button btnbutton,editbtnbutton;
    private ImageView imageView;
    private ProgressBar progressbar;
    private Uri imageurl;
    boolean isimageadd=false;
    final static  int REQUEST_CODE_IMAGE=101;
    Bookmodel bookmodel;
    private String bookid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_managebook);
        editTextfullname=findViewById(R.id.fullname);
        editTextphone=findViewById(R.id.phonenumber);
        editTextdate=findViewById(R.id.date);
        editTextdestination=findViewById(R.id.destination);
        editbtnbutton=findViewById(R.id.editbtnbutton);
        imageView=findViewById(R.id.imageupload);
        btnbutton=findViewById(R.id.btnbutton);
        progressbar=findViewById(R.id.progressone);
        String bookkey=getIntent().getStringExtra("bookkey");
        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference().child("book");
        //Storageref = FirebaseStorage.getInstance().getReference().child("bookimage");
//        ActivityResultLauncher<String> finalMGetContent= registerForActivityResult(new ActivityResultContracts.GetContent(),
//                result -> {
//                    if (result != null) {
//                        imageurl = result;
//                        isimageadd = true;
//                        // till now the image selected
//                        //set to imageview
//                        imageView.setImageURI(imageurl);
//                    }
//                });
       // imageView.setOnClickListener(view ->finalMGetContent.launch("image/*"));
//        editbtnbutton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                progressbar.setVisibility(View.VISIBLE);
//                btnbutton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        final String fullname = editTextfullname.getText().toString();
//                        final String phonenumber = editTextphone.getText().toString();
//                        final String date = editTextdate.getText().toString();
//                        final String destination = editTextdestination.getText().toString();
//                        final String bookid=fullname;
//                        if (destination.isEmpty()){
//                            editTextdestination.setError("fill destination");
//                        }
//                        else if (fullname.isEmpty()){
//                            editTextfullname.setError("fill the name");
//                        }
//                        else if (phonenumber.length()<9||phonenumber.length()>11){
//                            editTextphone.setError("fill the phone correctly");
//                        }
//                        else if (date.isEmpty()){
//                            editTextdate.setError("fill the date correctly");
//                        }
//                        else if(imageurl==null) {
//                            Toast.makeText(getApplicationContext(), "please select the image", Toast.LENGTH_SHORT).show();
//
//                        }
//                        else{
//                            uploadimage(fullname,phonenumber,date,destination,bookid);
//
//                        }
//                    }
//                });
//
//            }
//        });
        btnbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deletebook();
            }
        });

    }

//    private void uploadimage(String fullname, String phonenumber,
//                             String date, String destination,String bookid) {
//        progressbar.setVisibility(View.VISIBLE);
//        Storageref.child(bookid+".jpg").putFile(imageurl).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//            @Override
//            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//
//                Storageref.child(bookid+".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
//                    @Override
//                    public void onSuccess(Uri uri) {
//                        HashMap hashMap=new HashMap<>();
//                        hashMap.put("FULL NAME",fullname);
//                        hashMap.put("PHONE NUMBER",phonenumber);
//                        hashMap.put("date",date);
//                        hashMap.put("destination",destination);
//                        hashMap.put("imageurl",uri.toString());
//                        hashMap.put("bookid",bookid);
//
//                        databaseReference.child(bookid).setValue(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
//                            @Override
//                            public void onSuccess(Void unused) {
//                                progressbar.setVisibility(View.INVISIBLE);
//                                startActivity(new Intent(getApplicationContext(), REGISTRATIONActivity.class));
//                                Toast.makeText(getApplicationContext(), "DATA uploaded successfully", Toast.LENGTH_SHORT).show();
//                            }
//                        });
//                    }
//                });
//
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                progressbar.setVisibility(View.INVISIBLE);
//                startActivity(new Intent(getApplicationContext(), REGISTRATIONActivity.class));
//                Toast.makeText(getApplicationContext(), "fail to upload", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//
//
//
//    }

    private void deletebook() {
        databaseReference.removeValue();
        Toast.makeText(this, "book deleted", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), SEEUPLOADEDANNOUNCEActivity.class));
    }
}